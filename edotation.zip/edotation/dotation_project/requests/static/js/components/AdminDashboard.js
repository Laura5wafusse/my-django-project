import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Monitor, Users, AlertCircle, CheckCircle, Clock } from 'lucide-react';

const AdminDashboard = ({ data }) => {
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const getStatusColor = (status) => {
    const colors = {
      'pending': 'bg-yellow-100 text-yellow-800',
      'approved': 'bg-green-100 text-green-800',
      'rejected': 'bg-red-100 text-red-800',
      'in_progress': 'bg-blue-100 text-blue-800',
      'completed': 'bg-purple-100 text-purple-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusBadge = (status) => {
    const labels = {
      'pending': 'En attente',
      'approved': 'Approuvé',
      'rejected': 'Rejeté',
      'in_progress': 'En cours',
      'completed': 'Terminé'
    };
    return labels[status] || status;
  };

  const StatCard = ({ title, value, icon: Icon, color }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600">{title}</p>
          <h2 className="text-3xl font-bold mt-2">{value}</h2>
        </div>
        <div className={`p-4 rounded-full ${color}`}>
          <Icon size={24} className="text-white" />
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* En-tête avec actions */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
        <h1 className="text-2xl font-bold">Tableau de Bord Administratif</h1>
        <div className="flex gap-4">
          <input
            type="text"
            placeholder="Rechercher..."
            className="p-2 border rounded-md"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <select 
            className="p-2 border rounded-md"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="all">Tous les statuts</option>
            <option value="pending">En attente</option>
            <option value="approved">Approuvé</option>
            <option value="rejected">Rejeté</option>
            <option value="in_progress">En cours</option>
            <option value="completed">Terminé</option>
          </select>
        </div>
      </div>

      {/* Statistiques */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Demandes Totales" 
          value={data.totalRequests}
          icon={Monitor}
          color="bg-blue-500"
        />
        <StatCard 
          title="En Attente" 
          value={data.pendingRequests}
          icon={Clock}
          color="bg-yellow-500"
        />
        <StatCard 
          title="Approuvées" 
          value={data.approvedRequests}
          icon={CheckCircle}
          color="bg-green-500"
        />
        <StatCard 
          title="Rejetées" 
          value={data.rejectedRequests}
          icon={AlertCircle}
          color="bg-red-500"
        />
      </div>

      {/* Graphique des demandes par département */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Demandes par Département</CardTitle>
        </CardHeader>
        <CardContent className="h-[300px]">
          <BarChart
            width={800}
            height={300}
            data={data.departmentStats}
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="value" fill="#3b82f6" name="Nombre de demandes" />
          </BarChart>
        </CardContent>
      </Card>

      {/* Table des demandes */}
      <Card>
        <CardHeader>
          <CardTitle>Gestion des Demandes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateur</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Département</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Équipement</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantité</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {data.requests.map((request, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{request.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{request.user}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{request.department}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{request.equipment}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{request.quantity}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(request.status)}`}>
                        {getStatusBadge(request.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <div className="flex space-x-2">
                        {request.status === 'pending' && (
                          <>
                            <button className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600">
                              Approuver
                            </button>
                            <button className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600">
                              Rejeter
                            </button>
                          </>
                        )}
                        <button className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600">
                          Détails
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;