from django.db import models
from django.contrib.auth.models import User
from django.db import models
from django.contrib.auth.models import User
from django.db.models import Count, Q
from datetime import datetime, timedelta
from django.db import models
from django.contrib.auth.models import User
from django.db.models import Count, Q
from django.utils import timezone
from datetime import datetime, timedelta


class EquipmentRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'En attente'),
        ('approved', 'Approuvé'),
        ('rejected', 'Rejeté'),
        ('in_progress', 'En cours'),
        ('completed', 'Terminé')
    ]

    EQUIPMENT_CHOICES = [
        ('computer', 'Ordinateur'),
        ('printer', 'Imprimante'),
        ('monitor', 'Écran'),
        ('keyboard', 'Clavier'),
        ('mouse', 'Souris')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    equipment_type = models.CharField(max_length=50, choices=EQUIPMENT_CHOICES)
    quantity = models.IntegerField(default=1)
    reason = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    rejection_reason = models.TextField(blank=True, null=True)  # Changez le nom du champ

    def __str__(self):
        return f"{self.user.username} - {self.equipment_type} - {self.status}"

    @classmethod
    def get_dashboard_stats(cls):
        # Total des demandes
        total_requests = cls.objects.count()

        # Demandes par statut
        status_counts = cls.objects.values('status').annotate(count=Count('id'))

        # Demandes par département
        dept_counts = cls.objects.values(
            'user__profile__department'
        ).annotate(count=Count('id'))

        # Demandes par type d'équipement
        equipment_counts = cls.objects.values(
            'equipment_type'
        ).annotate(count=Count('id'))

        # Dernière période (7 jours)
        seven_days_ago = timezone.now() - timedelta(days=5)
        recent_requests = cls.objects.filter(
            created_at__gte=seven_days_ago,
        ).count()

        return {
            'total_requests': total_requests,
            'status_counts': list(status_counts),
            'department_stats': list(dept_counts),
            'equipment_stats': list(equipment_counts),
            'recent_requests': recent_requests
        }