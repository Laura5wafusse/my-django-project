from django.urls import path
from . import views

urlpatterns = [
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('manage-request/<int:request_id>/', views.manage_requests, name='manage_request'),
    path('test-email/', views.test_email_connection, name='test_email'),
    path('test-smtp/', views.test_smtp_connection, name='test_smtp'),
    path('verify-smtp/', views.verify_smtp_settings, name='verify_smtp'),
]