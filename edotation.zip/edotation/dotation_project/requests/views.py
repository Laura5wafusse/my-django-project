from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import user_passes_test
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
import logging
from .models import EquipmentRequest
import socket
from smtplib import SMTP
from django.core.mail import send_mail
from django.conf import settings
import socket
from smtplib import SMTP
from django.core.mail import send_mail
from django.conf import settings
from django.http import JsonResponse
import time
from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
import smtplib
import socket
import ssl
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
import smtplib
import socket
import ssl
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


logger = logging.getLogger(__name__)


def is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == 'admin'


@user_passes_test(is_admin, login_url='login')
def manage_requests(request, request_id=None):
    if request_id:
        equipment_request = get_object_or_404(EquipmentRequest, id=request_id)

        if request.method == 'POST':
            action = request.POST.get('action')

            try:
                # Préparation du message
                if action == 'approve':
                    equipment_request.status = 'approved'
                    subject = 'Demande de matériel approuvée'
                    message = f"""
Bonjour {equipment_request.user.username},

Votre demande de matériel a été approuvée:
- Type de matériel: {equipment_request.get_equipment_type_display()}
- Quantité: {equipment_request.quantity}

Vous pouvez passer au service IT pour récupérer votre matériel.

Cordialement,
Le Service IT
                    """
                elif action == 'reject':
                    equipment_request.status = 'rejected'
                    rejection_reason = request.POST.get('rejection_reason', '')
                    equipment_request.rejection_reason = rejection_reason
                    subject = 'Demande de matériel rejetée'
                    message = f"""
Bonjour {equipment_request.user.username},

Votre demande de matériel a été rejetée:
- Type de matériel: {equipment_request.get_equipment_type_display()}
- Quantité: {equipment_request.quantity}
- Motif du rejet: {rejection_reason}

Pour plus d'informations, vous pouvez contacter le service IT.

Cordialement,
Le Service IT
                    """

                # Sauvegarde de la demande
                equipment_request.save()

                # Log des informations d'envoi
                logger.info(f"Tentative d'envoi d'email à {equipment_request.user.email}")
                logger.info(f"Configuration SMTP: {settings.EMAIL_HOST}:{settings.EMAIL_PORT}")
                logger.info(f"Utilisateur SMTP: {settings.EMAIL_HOST_USER}")

                # Envoi de l'email
                send_mail(
                    subject=subject,
                    message=message,
                    from_email=settings.EMAIL_HOST_USER,
                    recipient_list=[equipment_request.user.email],
                    fail_silently=False
                )

                logger.info("Email envoyé avec succès")
                messages.success(request, f'La demande a été {action}e et un email a été envoyé')

            except Exception as e:
                logger.error(f"Erreur lors de l'envoi de l'email: {str(e)}")
                messages.error(request,
                               f"La demande a été {action}e mais l'envoi de l'email a échoué: {str(e)}")

            return redirect('admin_dashboard')

        return render(request, 'requests/manage_requests.html', {
            'request': equipment_request
        })

    return redirect('admin_dashboard')




def test_email_connection(request):
    logger.info("Démarrage du test de connexion email")

    try:
        # Test étape par étape avec timeout réduit
        logger.info(f"Tentative de connexion à {settings.EMAIL_HOST}:{settings.EMAIL_PORT}")
        start_time = time.time()

        # Étape 1: Création de la connexion
        smtp = SMTP(settings.EMAIL_HOST, settings.EMAIL_PORT, timeout=10)
        logger.info(f"Connexion établie en {time.time() - start_time:.2f} secondes")

        # Étape 2: Démarrage TLS
        smtp.set_debuglevel(1)
        logger.info("Démarrage TLS...")
        smtp.starttls()
        logger.info("TLS établi")

        # Étape 3: Login
        logger.info("Tentative de login avec:")
        logger.info(f"USER: {settings.EMAIL_HOST_USER}")
        logger.info(f"PASSWORD: {'*' * len(settings.EMAIL_HOST_PASSWORD)}")
        smtp.login(settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD)
        logger.info("Login réussi")

        # Étape 4: Envoi test
        sender = settings.EMAIL_HOST_USER
        recipient = request.user.email
        message = f"""
From: {sender}
To: {recipient}
Subject: Test Email Django

Ceci est un email de test envoyé depuis Django.
"""
        smtp.sendmail(sender, [recipient], message)
        logger.info("Email envoyé avec succès")

        smtp.quit()
        total_time = time.time() - start_time
        logger.info(f"Test complet terminé en {total_time:.2f} secondes")

        messages.success(request, f"Test email réussi en {total_time:.2f} secondes!")

    except socket.timeout as e:
        logger.error(f"Timeout de connexion: {str(e)}")
        messages.error(request, f"Erreur: Timeout de connexion après {time.time() - start_time:.2f} secondes")
    except Exception as e:
        logger.error(f"Erreur lors du test: {str(e)}")
        messages.error(request, f"Erreur: {str(e)}")

    return redirect('admin_dashboard')


@user_passes_test(is_admin)
def admin_dashboard(request):
    stats = EquipmentRequest.get_dashboard_stats()
    pending_requests = EquipmentRequest.objects.filter(status='pending')
    # Récupérer les 10 dernières demandes, tous statuts confondus
    latest_requests = EquipmentRequest.objects.all().order_by('-created_at')[:10]

    return render(request, 'requests/admin_dashboard.html', {
        'pending_requests': pending_requests,
        'latest_requests': latest_requests,
        'stats': stats
    })


def test_smtp_connection(request):
    """Test SMTP avec plusieurs configurations"""
    # Configurations à tester
    configs = [
        {'port': 587, 'timeout': 30, 'use_tls': True},
        {'port': 465, 'timeout': 30, 'use_ssl': True},
        {'port': 2525, 'timeout': 30, 'use_tls': True}
    ]

    host = settings.EMAIL_HOST
    username = settings.EMAIL_HOST_USER
    password = settings.EMAIL_HOST_PASSWORD

    for config in configs:
        try:
            print(f"\nTest avec configuration:")
            print(f"Port: {config['port']}")
            print(f"Timeout: {config['timeout']} secondes")
            print(f"TLS: {config.get('use_tls', False)}")
            print(f"SSL: {config.get('use_ssl', False)}")

            # Création de la connexion
            if config.get('use_ssl'):
                server = smtplib.SMTP_SSL(host, config['port'], timeout=config['timeout'])
                print("Connexion SSL établie")
            else:
                server = smtplib.SMTP(host, config['port'], timeout=config['timeout'])
                if config.get('use_tls'):
                    server.starttls(context=ssl.create_default_context())
                    print("Connexion TLS établie")

            # Test de connexion basique
            server.ehlo()
            print("Test EHLO réussi")

            # Authentification
            server.login(username, password)
            print("Authentification réussie")

            # Envoi d'un email de test
            msg = MIMEMultipart()
            msg['From'] = username
            msg['To'] = request.user.email
            msg['Subject'] = "Test SMTP réussi"
            msg.attach(MIMEText("Test de connexion SMTP réussi!", 'plain'))

            server.send_message(msg)
            print("Email envoyé avec succès")

            server.quit()
            print("Connexion fermée proprement")

            messages.success(request, f"Test réussi avec le port {config['port']}!")
            return redirect('admin_dashboard')

        except socket.timeout as e:
            print(f"Timeout sur le port {config['port']}: {str(e)}")
            continue
        except Exception as e:
            print(f"Erreur sur le port {config['port']}: {str(e)}")
            continue

    messages.error(request, "Échec de toutes les tentatives de connexion SMTP")
    return redirect('admin_dashboard')


def verify_smtp_settings(request):
    """Vérification des paramètres SMTP"""
    print("\nVérification des paramètres SMTP:")
    print(f"HOST: {settings.EMAIL_HOST}")
    print(f"PORT: {settings.EMAIL_PORT}")
    print(f"USER: {settings.EMAIL_HOST_USER}")
    print(f"TLS: {settings.EMAIL_USE_TLS}")
    print(f"PASSWORD LENGTH: {len(settings.EMAIL_HOST_PASSWORD)}")

    messages.info(request, "Vérification des paramètres effectuée - voir la console")
    return redirect('admin_dashboard')


