
default_app_config = 'requests.apps.RequestsConfig'  # pour le dossier requests