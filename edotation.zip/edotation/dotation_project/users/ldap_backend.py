from ldap3 import Server, Connection, ALL, NTLM, SUBTREE
from django.contrib.auth.models import User
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


class LDAPBackend:
    def authenticate(self, request, username=None, password=None):
        if not username or not password:
            return None

        try:
            # Configuration du serveur LDAP
            server = Server(settings.LDAP_SERVER, get_info=ALL)

            # Construction du DN de l'utilisateur
            user_filter = f'(&(objectClass=user)(sAMAccountName={username}))'

            # Connexion avec les credentials de service
            with Connection(server,
                            user=settings.LDAP_USER_DN,
                            password=settings.LDAP_USER_PASSWORD,
                            authentication=NTLM) as service_conn:

                # Recherche de l'utilisateur
                service_conn.search(
                    search_base=settings.LDAP_BASE_DN,
                    search_filter=user_filter,
                    search_scope=SUBTREE,
                    attributes=['mail', 'givenName', 'sn', 'department']
                )

                if not service_conn.entries:
                    logger.warning(f"Utilisateur {username} non trouvé dans AD")
                    return None

                user_dn = service_conn.entries[0].entry_dn

                # Test d'authentification de l'utilisateur
                try:
                    with Connection(server, user=user_dn, password=password, authentication=NTLM) as user_conn:
                        if user_conn.bound:
                            # Création ou mise à jour de l'utilisateur Django
                            try:
                                user = User.objects.get(username=username)
                            except User.DoesNotExist:
                                user = User(username=username)

                            # Mise à jour des informations
                            if service_conn.entries[0].givenName:
                                user.first_name = service_conn.entries[0].givenName.value
                            if service_conn.entries[0].sn:
                                user.last_name = service_conn.entries[0].sn.value
                            if service_conn.entries[0].mail:
                                user.email = service_conn.entries[0].mail.value

                            user.save()

                            # Mise à jour du profil
                            if hasattr(user, 'profile'):
                                if service_conn.entries[0].department:
                                    user.profile.department = service_conn.entries[0].department.value
                                user.profile.save()

                            return user
                except Exception as e:
                    logger.error(f"Erreur d'authentification pour {username}: {str(e)}")
                    return None

        except Exception as e:
            logger.error(f"Erreur LDAP: {str(e)}")
            return None

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None