from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegistrationForm, LoginForm
from requests.models import EquipmentRequest


def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                # Redirection différente selon le rôle
                if user.profile.role == 'admin':
                    return redirect('admin_dashboard')
                else:
                    return redirect('user_dashboard')
            else:
                messages.error(request, 'Identifiants invalides')
    else:
        form = LoginForm()
    return render(request, 'users/login.html', {'form': form})


def user_register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Compte créé pour {username}')
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'users/register.html', {'form': form})


@login_required
def user_dashboard(request):
    pending_requests = EquipmentRequest.objects.filter(user=request.user, status='pending')
    return render(request, 'users/user_dashboard.html', {
        'pending_requests': pending_requests
    })


@login_required
def make_request(request):
    if request.method == 'POST':
        equipment_type = request.POST.get('equipment_type')
        quantity = request.POST.get('quantity')
        reason = request.POST.get('reason')

        EquipmentRequest.objects.create(
            user=request.user,
            equipment_type=equipment_type,
            quantity=quantity,
            reason=reason,

        )
        messages.success(request, 'Votre demande a été soumise')
        return redirect('user_dashboard')

    return render(request, 'users/make_request.html')


@login_required
def request_history(request):
    requests = EquipmentRequest.objects.filter(user=request.user)
    return render(request, 'users/request_history.html', {'requests': requests})


@login_required
def track_request(request, request_id):
    equipment_request = EquipmentRequest.objects.get(id=request_id, user=request.user)
    return render(request, 'users/track_request.html', {'request': equipment_request})


def user_logout(request):
    logout(request)
    return redirect('login')