from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.user_login, name='login'),
    path('register/', views.user_register, name='register'),
    path('logout/', views.user_logout, name='logout'),
    path('dashboard/', views.user_dashboard, name='user_dashboard'),
    path('make-request/', views.make_request, name='make_request'),
    path('request-history/', views.request_history, name='request_history'),
    path('track-request/<int:request_id>/', views.track_request, name='track_request'),

]